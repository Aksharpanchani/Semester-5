!#/bin/bash

for N in {1..20}
do
	./cl 127.0.0.0
done
wait

